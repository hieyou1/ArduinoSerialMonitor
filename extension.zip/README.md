# ArduinoChromeSerialMonitor
A Arduino Serial Monitor extension for Chrome.

https://chrome.google.com/webstore/detail/arduino-chrome-serial-mon/opgcocnebgmkhcafcclmgfldjhlnacjd

![alt text](https://github.com/dalmirdasilva/ArduinoChromeSerialMonitor/blob/master/assets/screenshot.png "Screenshot")
